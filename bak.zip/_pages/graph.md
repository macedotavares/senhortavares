---
layout: page
title: Graph
id: graph
permalink: /graph
---

# The Whole Sort of General Mish Mash

{% include notes_graph.html %}